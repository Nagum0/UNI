﻿namespace HF1
{
    public enum Content
    {
        EMPTY,
        WALL,
        TREASURE,
        GHOST,
    }
}
