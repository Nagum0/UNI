namespace HF6 {
    public struct Item {
        public string id;
        public uint price;
    }
}
