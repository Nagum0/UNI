import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({
    ListUtilStructureTest.class
    , ListUtilTest.class
})
public class ListUtilSuite {}
