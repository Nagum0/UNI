package walking.game.util;

public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT,
}