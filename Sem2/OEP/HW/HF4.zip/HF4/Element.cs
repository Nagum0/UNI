﻿namespace HF4
{
    public struct Element
    {
        public int pr;
        public string data;
    }
}
