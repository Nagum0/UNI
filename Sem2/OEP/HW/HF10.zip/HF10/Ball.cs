﻿namespace HF10;

public class Ball : Gift {
    public Ball(Size size) : base(size) {}

    public override int Point() {
        return 1;
    }
}
