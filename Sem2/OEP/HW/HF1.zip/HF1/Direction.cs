﻿namespace HF1
{
    public struct Direction
    {
        public int x;
        public int y;
    }
}
