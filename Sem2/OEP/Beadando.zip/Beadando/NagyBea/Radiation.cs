﻿namespace NagyBea;

public interface Radiation {
    void Effect(Puffancs p);
    void Effect(Parabokor p);
    void Effect(Deltafa p);
}
