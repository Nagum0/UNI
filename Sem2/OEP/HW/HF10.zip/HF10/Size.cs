﻿namespace HF10;

public interface Size {
    abstract int Multi();
}
